# Antivirus-Python-

This is a project I started at the beginning of December 2017. I was simply bored out of my mind and needed a good topic for a term paper for school, so yeah here it is.
Since then it has gone from a console application to an "acceptable" GUI. 
This antivirus script is signature based only at the moment. I might add heuristics if I find the time to do so (school is hella work sometimes).
As I don't know where to safely get computer threats such as viruses, trojan horses, etc., the signatures that the AV uses come from VirusShare (https://virusshare.com/). I know that on their about-page it says, that scraping the website won't be tolerated, so I will not be responsible for the actions you perform with the software I made. I suggest to you that you look in your browser yourself to check if new Hash files were uploaded, and if you should not do it, the script is going to check, whether you have to download new ones/if new ones are available and you have not downloaded them so far. (Please do not penetrate my rectal hole Mr. VirusShare!!!)

Regarding what I just mentioned, if it should be a problem I will look into getting a server to make them available from there and as long as the problem exists and a server is not made available on my side I will take the program down (both crawler and Antivirus).
Screenshots will be uploaded in the following week.

If you should have any questions or any suggestions, here are some contact infos:
      - Reddit (I guess): https://www.reddit.com/user/CaptainReeetardo/
      - I am practically knew to GitHub, but I guess you can contact me here, too?!?!?!
